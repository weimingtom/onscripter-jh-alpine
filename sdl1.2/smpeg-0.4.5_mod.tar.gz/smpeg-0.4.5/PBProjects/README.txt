This is an unofficial OS X Project Builder environment to build a smpeg Framework.


Built with:
smpeg 0.4.4
Project Builder 2.0.1
OS X (10.2 Jaguar)

This project was created by brainlessly mimicking the SDL (Simple Direct Media 
Layer) Project Builder projects. The scripts were also shamelessly taken from 
SDL as well. There may be errors. Use at your own risk!

This project creates 2 installer packages:

- A smpeg framework for development (for people who wish to link to smpeg)

- A smpeg framework for users (for users who run programs that used the above 
package

This project also builds static libraries for smpeg they are not installed anywhere. If you wish to use them, you will need to 
copy them out of the build directory.

Eric Wing <ewing2121@yahoo.com>

